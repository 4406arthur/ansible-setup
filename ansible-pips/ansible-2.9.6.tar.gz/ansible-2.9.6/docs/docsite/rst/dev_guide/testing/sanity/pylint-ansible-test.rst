:orphan:

pylint-ansible-test
===================

Python static analysis for common programming errors.

A more strict set of rules applied to ``ansible-test``.
